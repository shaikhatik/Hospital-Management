﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Security;
using System.Data;
using System.IO;


public partial class adddoctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            getrollno();

        }
    }
    
    public void getrollno()
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        String myquery = "select Doct_Id from Doctor";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = myquery;
        cmd.Connection = con;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count < 1)
        {
            Label7.Text = "1001";

        }
        else
        {



            string connStr2 = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con2 = new SqlConnection(connStr2);
            String myquery1 = "select max(Doct_Id) from Doctor ";
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandText = myquery1;
            cmd1.Connection = con2;
            SqlDataAdapter da1 = new SqlDataAdapter();
            da1.SelectCommand = cmd1;
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            Label7.Text = ds1.Tables[0].Rows[0][0].ToString();
            int a;
            a = Convert.ToInt16(Label7.Text);
            a = a + 1;
            Label7.Text = a.ToString();
            con2.Close();
        }

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        string doctorName = TextBox1.Text.ToString();
        string Email = TextBox2.Text.ToString();
        string Mobile = TextBox3.Text.ToString();
        string Specialisation = TextBox4.Text.ToString();
        string Salary = TextBox5.Text.ToString();
        string Address = TextBox6.Text.ToString();
        string Pass = TextBox7.Text.ToString();

        if (doctorName != null && Email != null && Mobile != null && Specialisation != null && Salary != null && Address != null && Pass != null)
        {
            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);

            {
                SqlCommand cmd = new SqlCommand(" INSERT INTO Doctor (Doct_id, DName,Address,Email,Mobile,Specialist,Salary,Password) VALUES (@Id, @name, @Address, @Email,@Mobile,@specia,@Salary,@Pass)", con);

                con.Open();

                cmd.Parameters.AddWithValue("@id", Label7.Text);
                cmd.Parameters.AddWithValue("@name", doctorName);
                cmd.Parameters.AddWithValue("@Address", Address);
                cmd.Parameters.AddWithValue("@Email", Email);
                cmd.Parameters.AddWithValue("@Mobile", Mobile);
                cmd.Parameters.AddWithValue("@specia", Specialisation);
                cmd.Parameters.AddWithValue("@Salary", Salary);
                cmd.Parameters.AddWithValue("@Pass", Pass);





                cmd.ExecuteNonQuery();

                Response.Write("<script language=javascript>alert('Added Successfully')</script>");
                getrollno();
                TextBox1.Text = null;
                TextBox2.Text = null;
                TextBox3.Text = null;
                TextBox4.Text = null;
                TextBox5.Text = null;
                TextBox6.Text = null;
                TextBox7.Text = null;


               

            }
        }





    }
}