﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Security;
using System.Data;
using System.IO;


public partial class adddoctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);
            string PId = Request.QueryString["PId"].ToString();

            string sql = "SELECT * FROM Patient where PId = '" + PId + "'" ;
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandText = sql;
            cmd.Connection = con;
            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            {

                DataTable dt = new DataTable();
                sda.Fill(dt);
                
                Label3.Text = dt.Rows[0]["PName"].ToString();
                Label4.Text = dt.Rows[0]["StartDate"].ToString();
                Label5.Text = System.DateTime.Now.ToString();

                Label7.Text = "";
                TextBox1.Text = "";

            }
        }

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
       
    }
}