﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Security;
using System.Data;
using System.IO;


public partial class adddoctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            getrollno();
           
        }
        Drp_Item();

    }
    private void Drp_Item()
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from Doctor ", con);
        DropDownList2.DataSource = cmd.ExecuteReader();
        DropDownList2.DataTextField = "DName";
        DropDownList2.DataValueField = "Doct_Id";
        DropDownList2.DataBind();
        DropDownList2.Items.Insert(0, "SELECT");
        con.Close();
    }
    public void getrollno()
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        String myquery = "select PId from Patient";
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = myquery;
        cmd.Connection = con;
        SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        if (ds.Tables[0].Rows.Count < 1)
        {
            Label7.Text = "1001";

        }
        else
        {



            string connStr2 = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con2 = new SqlConnection(connStr2);
            String myquery1 = "select max(PId) from Patient";
            SqlCommand cmd1 = new SqlCommand();
            cmd1.CommandText = myquery1;
            cmd1.Connection = con2;
            SqlDataAdapter da1 = new SqlDataAdapter();
            da1.SelectCommand = cmd1;
            DataSet ds1 = new DataSet();
            da1.Fill(ds1);
            Label7.Text = ds1.Tables[0].Rows[0][0].ToString();
            int a;
            a = Convert.ToInt16(Label7.Text);
            a = a + 1;
            Label7.Text = a.ToString();
            con2.Close();
        }

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        string Name = TextBox1.Text.ToString();
        string Address = TextBox2.Text.ToString();
        string Mobile = TextBox3.Text.ToString();
        string Disease = TextBox4.Text.ToString();
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand(" INSERT INTO Patient (PId, PName,Address,Mobile,Disease,DName,Room, StartDate) VALUES (@Id, @name, @Address, @Mobile, @Disease,@DName,@Room,@Date)", con);

        con.Open();

        cmd.Parameters.AddWithValue("@id", Label7.Text);
        cmd.Parameters.AddWithValue("@name", Name);
        cmd.Parameters.AddWithValue("@Address", Address);
        cmd.Parameters.AddWithValue("@Mobile", Mobile);
        cmd.Parameters.AddWithValue("@Disease", Disease);
        cmd.Parameters.AddWithValue("@DName", DropDownList2.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@Room", DropDownList1.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@Date", TextBox5.Text);

        cmd.ExecuteNonQuery();
        Response.Write("<script language=javascript>alert('Added Successfully')</script>");

        con.Close();
        getrollno();
        TextBox1.Text = null;
        TextBox2.Text = null;
        TextBox3.Text = null;
        TextBox4.Text = null;
        TextBox5.Text = null;
        DropDownList1.SelectedIndex = 0;
        DropDownList2.SelectedIndex = 0;

    }
}


