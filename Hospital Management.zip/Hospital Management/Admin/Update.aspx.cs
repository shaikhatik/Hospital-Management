﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Web.Security;
using System.Data;
using System.IO;


public partial class adddoctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);

            string PId = Request.QueryString["Doct_Id"].ToString();
            string sql = "SELECT * FROM Doctor where Doct_Id= '" + PId + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandText = sql;
            cmd.Connection = con;
            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            {

                DataTable dt = new DataTable();
                sda.Fill(dt);
                TextBox1.Text = dt.Rows[0]["DName"].ToString();
                TextBox6.Text = dt.Rows[0]["Address"].ToString();
                TextBox2.Text = dt.Rows[0]["Email"].ToString();
                TextBox3.Text = dt.Rows[0]["Mobile"].ToString();
                TextBox4.Text = dt.Rows[0]["Specialist"].ToString();
                TextBox5.Text = dt.Rows[0]["Salary"].ToString();

            }
        }
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        
        string i = "update Doctor Set DName = @DName, Address=@Address, Email=@Email, Mobile=@Mobile, Specialist=@Specialist, Salary=@Salary where DName = @DName";
        SqlCommand cmd = new SqlCommand(i, con);
        cmd.Parameters.AddWithValue("@DName", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Address", TextBox6.Text);
        cmd.Parameters.AddWithValue("@Email", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Mobile", TextBox3.Text);
        cmd.Parameters.AddWithValue("@Specialist", TextBox4.Text);
        cmd.Parameters.AddWithValue("@Salary", TextBox5.Text);
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        Response.Write("<script language=javascript>alert('Updated Successfully')</script>");

    }
}




