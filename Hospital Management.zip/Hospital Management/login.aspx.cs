﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        HttpCookie userCookie;
        userCookie = Request.Cookies["Preferences"];

        if (userCookie != null)
        {
            if (!userCookie.Value.Equals(-1))
            {
                Session.Clear();
                Session["Login"] = Request["usrname"];
                Response.Redirect("about.aspx");
            }
        }
    }


    protected void Button1_Click1(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        string i = "select * from Doctor where DName = @DName and Password=@Password";
        SqlCommand cmd = new SqlCommand(i, con);
        cmd.Parameters.AddWithValue("@DName", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Password", TextBox2.Text);
        SqlDataAdapter sda = new SqlDataAdapter();
        sda.SelectCommand = cmd;
        DataTable dt = new DataTable();
        con.Open();
        sda.Fill(dt);
        SqlDataReader rd = cmd.ExecuteReader();
        if (rd.HasRows)
        {
            rd.Read();
            Session["username"] = rd["DName"].ToString();
            Session["Name"] = dt.Rows[0]["Name"].ToString();
            Session["Surname"] = dt.Rows[0]["Surname"].ToString();
            
            Response.Redirect("Doctor/Home.aspx");

        }
        else if (TextBox1.Text == "Admin" & TextBox2.Text == "Admin123")
        {
            Session["admin"] = TextBox1.Text;
            Response.Redirect("Admin/Add Patient.aspx");
        }
        else
        {
            Response.Write("<script language=javascript>alert('Added Successfully')</script>");
        }



    }
}