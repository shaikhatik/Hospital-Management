﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Doctors_My_Account : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack == false)
        {
            string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
            SqlConnection con = new SqlConnection(connStr);
            string sql = "SELECT * FROM Doctor where DName = '" + Session["Username"] + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.CommandText = sql;
            cmd.Connection = con;
            using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            {

                DataTable dt = new DataTable();
                sda.Fill(dt);
                
                lblname.Text = dt.Rows[0]["DName"].ToString();               
                lbladdrss.Text = dt.Rows[0]["Address"].ToString();               
                lblmobile.Text = dt.Rows[0]["Mobile"].ToString();
                lblspec.Text = dt.Rows[0]["Specialist"].ToString();
                lblsal.Text = dt.Rows[0]["Salary"].ToString();

            }
        }
        
        MultiView1.ActiveViewIndex = 0;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        string i = "update Doctor Set DName = @DName, Address=@Address, Mobile=@Mobile, Specialist=@Specialist where DName = @DName";
        SqlCommand cmd = new SqlCommand(i, con);
        cmd.Parameters.AddWithValue("@DName", txtname.Text);

        cmd.Parameters.AddWithValue("@Address", txtaddd.Text);
        cmd.Parameters.AddWithValue("@Mobile", txtmpbile.Text);

        cmd.Parameters.AddWithValue("@Specialist", txtspec.Text);
        cmd.Connection = con;
        con.Open();
        cmd.ExecuteNonQuery();
        Response.Write("<script language=javascript>alert('Added Successfully')</script>");
        string sql = "SELECT * FROM Doctor where DName = '" + Session["Username"] + "'";
        SqlCommand cmd1 = new SqlCommand(sql, con);

        using (SqlDataAdapter sda = new SqlDataAdapter(cmd1))
        {

            DataTable dt = new DataTable();
            sda.Fill(dt);    
            txtname.Text = dt.Rows[0]["DName"].ToString();
            txtaddd.Text = dt.Rows[0]["Address"].ToString();
            txtmpbile.Text = dt.Rows[0]["Mobile"].ToString();
            txtspec.Text = dt.Rows[0]["Specialist"].ToString();
            lblsal.Text = dt.Rows[0]["Salary"].ToString();
            
        }
        con.Close();
        MultiView1.ActiveViewIndex = -1;
    }



    protected void Button4_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        string sql = "SELECT * FROM Doctor where DName = '" + Session["Username"] + "'";
        SqlCommand cmd = new SqlCommand(sql, con);
        cmd.CommandText = sql;
        cmd.Connection = con;
        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
        {

            DataTable dt = new DataTable();
            sda.Fill(dt);
            txtname.Text = dt.Rows[0]["DName"].ToString();
            txtaddd.Text = dt.Rows[0]["Address"].ToString();
            txtmpbile.Text = dt.Rows[0]["Mobile"].ToString();
            txtspec.Text = dt.Rows[0]["Specialist"].ToString();
            lblsal.Text = dt.Rows[0]["Salary"].ToString();


        }

    }
}