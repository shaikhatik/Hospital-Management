﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Net.Mail;
using System.Net;
using System.Data.Sql;
using System.Configuration;

using System.Text;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        SqlCommand cmd = new SqlCommand(" INSERT INTO feedback (Name,Email,Text) VALUES (@name, @Email, @Text)", con);
        con.Open();       
        cmd.Parameters.AddWithValue("@name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Email", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Text", TextBox1.Text);
        cmd.ExecuteNonQuery();
        Response.Write("<script language=javascript>alert('Added Successfully')</script>");

        con.Close();
        
        TextBox1.Text = null;
        TextBox2.Text = null;
        TextBox3.Text = null;
       


    }
}