﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        string connStr = ConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
        SqlConnection con = new SqlConnection(connStr);
        con.Open();

        SqlCommand select = new SqlCommand();
        select.Connection = con;

        select.CommandText = "select DName from Doctor where DName = '" + TextBox1.Text + "' and Password = '" + TextBox2.Text + "' ";
        

        SqlDataReader rd = select.ExecuteReader();
        if (rd.HasRows)
        {
            rd.Read();
            Session["Username"] = rd["DName"].ToString();
            

            Response.Redirect("Doctors/home.aspx");
        }
        else if (TextBox1.Text == "Admin" & TextBox2.Text == "Admin123")
        {
            Session["admin"] = TextBox1.Text;
            Response.Redirect("Admin/Add Patient.aspx");
        }
        else
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Invalid Log in Data');</script>");
        }

        rd.Close();
        con.Close();
    }

}
